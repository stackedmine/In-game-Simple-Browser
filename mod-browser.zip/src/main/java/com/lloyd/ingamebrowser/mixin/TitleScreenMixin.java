package com.lloyd.ingamebrowser.mixin;

import com.lloyd.ingamebrowser.InGameBrowserScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public class TitleScreenMixin extends Screen {
    protected TitleScreenMixin(Text title) { super(title); }

    @Inject(at = @At("TAIL"), method = "init")
    private void addBrowserButton(CallbackInfo ci) {
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Браузер"), button -> {
            if (this.client != null) {
                this.client.setScreen(new InGameBrowserScreen());
            }
        }).dimensions(10, 10, 70, 20).build());
    }
}
