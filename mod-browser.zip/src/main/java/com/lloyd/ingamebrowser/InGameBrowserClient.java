package com.lloyd.ingamebrowser;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class InGameBrowserClient implements ClientModInitializer {
    public static KeyBinding openBrowserKey;

    @Override
    public void onInitializeClient() {
        openBrowserKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ingamebrowser.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_B,
                "category.ingamebrowser"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openBrowserKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new InGameBrowserScreen());
                }
            }
        });
    }
}
