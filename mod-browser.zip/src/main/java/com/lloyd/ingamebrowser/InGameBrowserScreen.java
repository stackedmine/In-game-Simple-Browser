package com.lloyd.ingamebrowser;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class InGameBrowserScreen extends Screen {
    private TextFieldWidget urlField;
    private List<String> pageContent = new ArrayList<>();
    private String statusText = "Введите URL и нажмите GO";

    public InGameBrowserScreen() {
        super(Text.literal("Java Browser"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;

        this.urlField = new TextFieldWidget(this.textRenderer, centerX - 150, 30, 220, 20, Text.literal("URL"));
        this.urlField.setMaxLength(256);
        this.urlField.setText("https://google.com");
        this.addSelectableChild(this.urlField);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("GO"), button -> {
            loadWebPage(this.urlField.getText());
        }).dimensions(centerX + 75, 30, 45, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Закрыть"), button -> {
            this.close();
        }).dimensions(centerX - 50, this.height - 30, 100, 20).build());
    }

    private void loadWebPage(String url) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "https://" + url;
        }

        statusText = "Загрузка...";
        pageContent.clear();
        String finalUrl = url;

        new Thread(() -> {
            try {
                HttpClient client = HttpClient.newBuilder()
                        .followRedirects(HttpClient.Redirect.ALWAYS)
                        .build();

                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(finalUrl))
                        .header("User-Agent", "Mozilla/5.0 (Android; Mobile)")
                        .GET()
                        .build();

                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                
                String html = response.body();
                String plainText = html.replaceAll("<script[\\s\\S]*?</script>", "")
                                       .replaceAll("<style[\\s\\S]*?</style>", "")
                                       .replaceAll("<[^>]*>", "")
                                       .replaceAll("(?m)^[ \t]*\r?\n", "");

                String[] lines = plainText.split("\n");
                for (int i = 0; i < Math.min(lines.length, 15); i++) {
                    if (!lines[i].trim().isEmpty()) {
                        pageContent.add(lines[i].trim());
                    }
                }

                statusText = "Готово (Код: " + response.statusCode() + ")";
            } catch (Exception e) {
                statusText = "Ошибка: " + e.getMessage();
            }
        }).start();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);

        this.urlField.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(statusText), this.width / 2, 58, 0xAAAAAA);

        int startY = 80;
        for (String line : pageContent) {
            if (startY > this.height - 50) break;
            context.drawTextWithShadow(this.textRenderer, Text.literal(line), 20, startY, 0xFFFFFF);
            startY += 12;
        }
    }
}
